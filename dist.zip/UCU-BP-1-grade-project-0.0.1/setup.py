from distutils.core import setup


setup(name='UCU-BP-1-grade-project',
      version='0.0.1',
      description='Metal bands research',
      author='ramskyi',
      license='MIT',
      url='https://github.com/ramskyi/UCU-BP-1-grade-project',
      packages=['src', 'polygon'],
      scripts=['main.py'])
