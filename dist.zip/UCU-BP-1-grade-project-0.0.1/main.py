import src.bands_list_scraper as bls
import src.collector as col
import src.status_analysis as sta


def main():
    bls.scrape_band_list()
    col.collect_and_store_band_data()
    sta.draw_all()


if __name__ == '__main__':
    main()
